<?php 
if( $_POST["comment"]) { 
      echo "Comment received: ".$_POST["comment"]."<br />"; 
} 
$conn = mysqli_connect("localhost", "root", "", "mydb"); 
if (!$conn) { 
die("Connection failed: ".mysqli_connect_error()); 
}
$sql = "INSERT INTO comments VALUES 
('". $_POST["comment"]."')";
if (mysqli_query($conn, $sql)) { 
      echo "New record created"; 
} else { 
      echo "Error: ".$sql; 
}
mysqli_close($conn);
?>