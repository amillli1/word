<?php 
$conn = mysqli_connect("localhost", "root", "", "mydb"); 
if (!$conn) { 
die("Connection failed: ".mysqli_connect_error()); 
}
$sql = "SELECT * FROM comments"; 
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) > 0){ 
    while($row = mysqli_fetch_assoc($result)){ 
       echo "Comment: ".$row["comment"]."<br />"; 
    } 
} else { 
    echo "No results"; 
}